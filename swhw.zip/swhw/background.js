// 監聽擴充功能圖示的點擊事件
chrome.action.onClicked.addListener((tab) => {
  // 確保點擊的是一個有效的網頁分頁
  if (tab.id) {
    // 向當前活動的分頁注入並執行 content.js 腳本
    chrome.scripting.executeScript({
      target: { tabId: tab.id }, // 指定目標分頁
      files: ['content.js']      // 要執行的腳本文件
    });
  } else {
    console.error("無法獲取當前分頁 ID。");
  }
});