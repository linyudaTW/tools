(function() {
  console.log("寬高交換腳本已注入");

  let widthInput = null;
  let heightInput = null;

  // 找到所有包含標籤和輸入框的父級容器 (n-form-item)
  const formItems = document.querySelectorAll('.n-form-item');

  formItems.forEach(item => {
    // 在每個容器內尋找標籤文字
    const labelSpan = item.querySelector('.n-form-item-label__text');
    if (labelSpan) {
      const labelText = labelSpan.textContent.trim();
      // 在同一個容器內尋找輸入框
      const inputElement = item.querySelector('input.n-input__input-el');

      if (inputElement) {
        if (labelText === '宽') {
          widthInput = inputElement;
          console.log("找到 '宽' 輸入框:", widthInput);
        } else if (labelText === '高') {
          heightInput = inputElement;
          console.log("找到 '高' 輸入框:", heightInput);
        }
      }
    }
  });

  // 檢查是否成功找到兩個輸入框
  if (widthInput && heightInput) {
    console.log("準備交換值...");
    console.log("交換前 - 宽:", widthInput.value, "高:", heightInput.value);

    // 交換值
    const tempValue = widthInput.value;
    widthInput.value = heightInput.value;
    heightInput.value = tempValue;

    console.log("交換後 - 宽:", widthInput.value, "高:", heightInput.value);

    // --- 重要：觸發輸入事件 ---
    // 許多現代網頁框架（如 Vue, React, Angular）會監聽 'input' 或 'change' 事件
    // 來更新內部狀態。僅僅修改 .value 可能不足以讓網頁正確反應變化。
    // 我們需要手動觸發這些事件。
    const eventInput = new Event('input', { bubbles: true });
    const eventChange = new Event('change', { bubbles: true });

    widthInput.dispatchEvent(eventInput);
    widthInput.dispatchEvent(eventChange);
    heightInput.dispatchEvent(eventInput);
    heightInput.dispatchEvent(eventChange);

    console.log("已觸發 input 和 change 事件");
    // 可以選擇性地給用戶一個視覺回饋
    // alert('寬度和高度值已成功交換！');

  } else {
    // 如果找不到，則在控制台輸出錯誤訊息
    if (!widthInput) {
      console.error("錯誤：找不到標記為 '宽' 的輸入框。請檢查網頁結構或選擇器。");
    }
    if (!heightInput) {
      console.error("錯誤：找不到標記為 '高' 的輸入框。請檢查網頁結構或選擇器。");
    }
    alert("錯誤：無法找到 '宽' 或 '高' 的輸入框。請查看控制台獲取詳細資訊。");
  }

})(); // 使用 IIFE (立即調用函數表達式) 避免污染全局作用域