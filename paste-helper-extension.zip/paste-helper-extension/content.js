chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "clearAndPaste") {
    const activeElement = document.activeElement;
    
    // 檢查當前焦點是否在可編輯元素上
    if (activeElement && (
        activeElement.tagName === 'INPUT' || 
        activeElement.tagName === 'TEXTAREA' || 
        activeElement.isContentEditable
      )) {
      
      // 清空當前內容
      if (activeElement.isContentEditable) {
        activeElement.innerHTML = '';
      } else {
        activeElement.value = '';
      }
      
      // 請求讀取剪貼簿並貼上內容
      navigator.clipboard.readText()
        .then(text => {
          if (activeElement.isContentEditable) {
            activeElement.innerHTML = text;
          } else {
            activeElement.value = text;
            
            // 觸發 input 事件以確保網頁能夠檢測到值的變化
            const inputEvent = new Event('input', { bubbles: true });
            activeElement.dispatchEvent(inputEvent);
          }
        })
        .catch(err => {
          console.error('無法讀取剪貼簿:', err);
        });
    } else {
      console.log('沒有選中的輸入框');
    }
  }
});